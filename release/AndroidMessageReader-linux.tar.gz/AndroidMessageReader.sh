#!/bin/sh -e

java -jar -Xmx256m AndroidMessageReader-all.jar
     